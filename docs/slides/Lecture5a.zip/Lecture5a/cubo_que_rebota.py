"""
File: circulos_aleatorios.py
-------------------
Dibuja 10 círculos al azar de modo que cada círculo esté en la pantalla.

"""

from graphics import Canvas
import random
# Esto es necesario para pausar el programa
import time

TAMANO_CUBO = 50

def crear_cubo(canvas):
    cubo = canvas.create_rectangle(20, 20, 20 + TAMANO_CUBO, 20 + TAMANO_CUBO)
    return cubo

def chocado_con_pared_hotizontal(canvas, cubo):
    """
    Devolver si cubo ha chocado con paredes horizontales
    # return boolean
    """
    top_y = canvas.get_top_y(cubo)
    bottom_y = canvas.get_top_y(cubo) + TAMANO_CUBO
    return bottom_y > canvas.get_canvas_height() or top_y < 0

def chocado_con_pared_vertical(canvas, cubo):
    """
    Devolver si cubo ha chocado con paredes vertical
    # return boolean
    """
    left_x = canvas.get_left_x(cubo)
    right_x = left_x + TAMANO_CUBO
    return left_x < 0 or right_x > canvas.get_canvas_width()


def main():
    canvas = Canvas()
    cubo = crear_cubo(canvas)
    dx = random.randint(1, 3)
    dy = random.randint(1, 4)
    while True:
        canvas.move(cubo, dx, dy)
        # estos dx dy tienen que cambiar
        # cuando el cubo choca con el pared
        # cambiar dx dy si el cubo choca con la pared

        random_color = canvas.get_random_color()
        # probar si el cubo ha chocado con la pared abajo
        # si el y posicion del cuba ha pasado del pared abajjo
        if chocado_con_pared_hotizontal(canvas, cubo):
            # hemos chocado con el pared de abajo
            dy = -dy
            canvas.set_fill_color(cubo, random_color)
        if chocado_con_pared_vertical(canvas, cubo):
            dx = -dx
            canvas.set_fill_color(cubo, random_color)

        canvas.update()
        time.sleep(0.01)




if __name__ == '__main__':
    main()
