"""
File: circulos_aleatorios.py
-------------------
Dibuja 10 círculos al azar de modo que cada círculo esté en la pantalla.

"""

from graphics import Canvas

# Esto es necesario para pausar el programa
import time


def main():
    """
    Crear un cuadrado
    """
    canvas = Canvas()
    # 1. crear un cadrado
    x1 = 0
    y1 = canvas.get_canvas_height()/2 - 25
    cuad = canvas.create_rectangle(x1,  y1, x1 + 50, y1 + 50)

    # 2. moverse esta caudrado a traves de la pantalla
    while canvas.get_left_x(cuad) + 50 < canvas.get_canvas_width():
        # se miueve el cuadrado 2 pixeles a la derecha
        canvas.move(cuad, 3, 0)
        canvas.update()
        # redibujar el canvas

        time.sleep(0.01)
        # pausa

    canvas.mainloop()



if __name__ == '__main__':
    main()
