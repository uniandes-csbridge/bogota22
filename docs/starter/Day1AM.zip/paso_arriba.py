from karel.stanfordkarel import *

"""
Archivo: paso_arriba.py
------------------------
El primer programa de ejemplo para Karel, toca que karel tome el 'beeper'
en frente suyo y lo ponga en el tope de la colina.
(este es un comentario, no será leido por la computadora.)
**NOTA: LAS FUNCIONES DE KAREL PERTINENTES HAN SIDO TRADUCIDAS AL ESPAÑOL**
------------------------
Palabras claves de Python en este programa:
def: definir función.
"""


def main():
    """
    Cuando inicies el programa, se correrá este código.
    """
    # TODO


# No te preocupes por este codigo, no debe modificarse.
if __name__ == "__main__":
    run_karel_program()
