from karel.stanfordkarel import *

"""
File: recoger_periodico.py
------------------------------
Actualmente, el documento recoger_periodico no hace nada. 
Tu deber en esta tarea es añadir el código necesario para instruir a Karel para que camine a las puerta de su casa, recoja el periódico (representado por un cono, por supuesto), y después regrese a su posición inicial en la esquina superior izquierda de la casa. 

"""


def main():
    """
    Debes escribir el código necesario para que Karel haga su deber en esta función. Asegúrate de borrar la linea que dice ‘pass’ al antes de comenzar a escribir tu propio código. También debes borrar este comentario y escribir uno más descriptivo. 
    """
    pass


#No debes editar nada mas a partir de aquí. No te preocupes por la función de abajo. 
if __name__ == "__main__":
    run_karel_program()
