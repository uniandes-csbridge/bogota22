from karel.stanfordkarel import *

"""
File: arcos_karel.py
------------------------------
Cuando termines de escribir el código de este documento, arcos_karel debe solucionar el problema de ‘reparar el palacio narino’ 
"""


def main():
    """
    Debes escribir el código necesario para que Karel haga su deber en esta función. Asegúrate de borrar la linea que dice ‘pass’ al antes de comenzar a escribir tu propio código. También debes borrar este comentario y escribir uno más descriptivo. 

    """
    pass


#No debes editar mas alla de este punto
if __name__ == "__main__":
    run_karel_program()
