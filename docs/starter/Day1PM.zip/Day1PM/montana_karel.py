from karel.stanfordkarel import *

"""
File: montana_karel.py
------------------------------
En este momento, este documento no hace nada. Tu deber es poner el cono en la cima de la montaña. Debes asegurarte que tu programa funcione en todos los mundos con montaña ejemplares proveídos en el folder.

"""


def main():
    """
    Debes escribir el código necesario para que Karel haga su deber en esta función. Asegúrate de borrar la linea que dice ‘pass’ al antes de comenzar a escribir tu propio código. También debes borrar este comentario y escribir uno más descriptivo. 

    """
    pass


# No debes editar mas allá de este punto 

if __name__ == "__main__":
    run_karel_program()
