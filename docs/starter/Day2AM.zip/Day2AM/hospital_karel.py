from karel.stanfordkarel import *

"""
File: hospital_karel.py
------------------------------
En este momento, este documento no hace nada.
"""


def main():
    """
    Debes escribir el código necesario para que Karel haga su deber
    en esta función. Asegúrate de borrar la linea que dice ‘pass’
    al antes de comenzar a escribir tu propio código. También debes
    borrar este comentario y escribir uno más descriptivo.
    """
    pass



# No debes editar mas allá de este punto
if __name__ == "__main__":
    run_karel_program()
