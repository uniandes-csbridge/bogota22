"""
File: hola_mundo.py
------------------
"""


def main():
    pass


if __name__ == "__main__":
    main()
