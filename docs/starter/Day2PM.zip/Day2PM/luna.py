"""
File: luna.py
------------------
Convierte el peso en la tierra en peso en la luna.
"""


def main():
    # tu codigo va aca...
    pass


if __name__ == "__main__":
    main()
