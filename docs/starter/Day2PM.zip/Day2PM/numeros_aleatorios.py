"""
File: numeros_aleatorios.py
------------------
Imprime 1,000 números al azar entre 0 y 100.
"""
from random import randint

def main():
    # cambiar este codigo para imprimir 1000 
    # numeros aleatorios en el rango de 0 a 100.   
    ejemplo = randint(0, 100);
    print(ejemplo)


if __name__ == "__main__":
    main()
