"""
File: suma_acumulada.py
-------------------
Escriba un programa que lea numeros y genere la
suma acumulada de los valores ingresados
"""


def main():
    # tu codigo va aca...    
    pass


if __name__ == '__main__':
    main()
