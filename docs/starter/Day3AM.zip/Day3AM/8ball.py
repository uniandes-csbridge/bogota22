"""
File: 8ball.py
-------------------
Escribe un programa que continuamente le pide al 
usuario una pregunta de sí o no, y aleatoriamente 
selecciona de 5 respuestas predeterminadas:
"""

# Esto es necesario para generar números aleatorios.
import random


def main():
    while True:
        input("Di una pregunta de si o no: ")

        # recuerda, esto es un comentario.
        # EMPIEZA TU CODIGO


        # TERMINA TU CODIGO


if __name__ == '__main__':
    main()
