"""
File: algo_suma.py
-------------------
Escriba un programa que lea 10 enteros del usuario e imprima 
la suma de los valores ingresados.
"""

def main():
    # TODO
    pass


if __name__ == '__main__':
    main()
