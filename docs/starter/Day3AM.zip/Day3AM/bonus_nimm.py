"""
File: bonus_nimm.py
-------------------
Ejecuta una version para dos jugadores del antiguo 
juego de Nimm.
"""

def main():
    # tu codigo va aca...  
    pass


if __name__ == '__main__':
    main()

