"""
File: video_viral.py
-------------------
Este codigo tome de entrada: 
    (1) un objetivo de vistas, 
    (2) una tasa de crecimiento. 

Tu programa debe computar el número de días que le toma llegar 
al objetivo.
"""


def main():
    # TODO
    pass


if __name__ == "__main__":
    main()
