"""
File: khansole_academy.py
-------------------
Este programa genere problemas sencillos de suma aleatorios para el usuario, 
que lea una respuesta del usuario, y después revise si esta bien o mal, hasta 
que el usuario haya dominado el material. 

Tu programa debería seguir dandole problemas al usuario hasta que el usuario 
haya conseguido 3 problemas correctos seguidos.
"""


# Esto es necesario para generar números aleatorios.
import random


def main():
    # TODO
    pass


if __name__ == "__main__":
    main()
