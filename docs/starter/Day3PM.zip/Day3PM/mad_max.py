"""
File: mad_max.py
--------------------
Complete la función mad_max para que retorna el numero mas grande de los 3 números:
"""


def main():
    print("El maximo de 4, 5, and 6 es:", mad_max(4, 5, 6))
    print("El maximo de -4, 4, and 0 es:", mad_max(-4, 4, 0))
    print("El maximo de 3, 2, and 1 es:", mad_max(3, 2, 1))
    print("El maximo de 0, 0, and 0 es:", mad_max(0, 0, 0))


def mad_max(x, y, z):
    """
    Esta funcion toma tres entradas (x, y, z) 
    y retorna la mayor de las tres.
    """
    # TODO: 
    pass


if __name__ == "__main__":
    main()
