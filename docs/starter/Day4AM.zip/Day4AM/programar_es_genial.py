"""
File: programar_es_genial.py
--------------------
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Programar es genial!")

    # TODO: su código aquí
    canvas.mainloop()


if __name__ == '__main__':
    main()
