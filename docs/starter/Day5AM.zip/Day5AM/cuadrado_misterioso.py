"""
File: cuadrado_misterioso.py
-------------------
"""

from graphics import Canvas
import time  # Esto es necesario para pausar el tiempo. No lo borre

# Tamaño del cuadrado centrado
TAMANO_DE_CUADRADO = 400

# Pausa entre cambios de color, en segundos
PAUSA = 1


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Cuadrado Misterioso")

    # TODO: su codigo aca

    canvas.mainloop()


if __name__ == "__main__":
    main()
