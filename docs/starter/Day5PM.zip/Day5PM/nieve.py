"""
File: nieve.py
-------------
Anime los copitos de nieve que caen del cielo y se acumulan en el suelo.
"""

from graphics import Canvas
import random
import time

# Pausa entre los cuadros, en segundos
PAUSA = 0.01
TAMANO_COPITOS = 10


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Nieve")
    
    # TODO: su codigo aca

    canvas.mainloop()


if __name__ == '__main__':
    main()
