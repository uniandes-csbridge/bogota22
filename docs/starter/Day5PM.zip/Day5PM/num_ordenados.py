"""
File: num_ordenados.py
-------------------
"""


def main():
    # TODO: su codigo aca
    pass


if __name__ == '__main__':
    main()
