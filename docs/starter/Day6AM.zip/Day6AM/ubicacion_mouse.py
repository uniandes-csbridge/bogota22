"""
File: ubicacion_mouse.py
-------------------
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Ubicacion de Mouse")

    # TODO: su codigo aca

    canvas.mainloop()


if __name__ == "__main__":
    main()
