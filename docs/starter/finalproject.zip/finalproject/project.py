"""
File: project.py
-----------------
"""

from graphics import Canvas


def main():
    pass


if __name__ == '__main__':
    main()
